package com.sonny.myapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.gson.Gson;

public class LoginFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.login_fragment, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setColorButtons(view);
        setRegisterButton(view);
    }

    private void setRegisterButton(View view) {
        Button registerButton = view.findViewById(R.id.register_button);
        registerButton.setOnClickListener(v->{
            moveToRegisterFragment();
        });
    }

    private void moveToRegisterFragment() {
        RegisterFragment fragment = new RegisterFragment();
        //R.id.container_id  ->   Parent activity container.
        FragmentTransaction transaction = requireActivity()
                .getSupportFragmentManager().beginTransaction();
        transaction.addToBackStack("LOGIN");

        transaction.replace(R.id.container_id,fragment).commit();
    }


    private void setColorButtons(View view)
    {
        Button redBt = view.findViewById(R.id.red_bt_id);
        ConstraintLayout layout = view.findViewById(R.id.layout_id);
        redBt.setOnClickListener(v->{
            layout.setBackgroundColor(getResources().getColor(R.color.light_red));
        });

    }


    private void saveData()
    {
        Account sonny = new Account();
        sonny.name = "Sonny";
        sonny.password = "321";

        Gson gson = new Gson();
        String json = gson.toJson(sonny);


        System.out.println("Json data is " + json);

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("Login", Context.MODE_PRIVATE);
        sharedPreferences.edit().putString("account",json).apply();

//        sharedPreferences.getString("account","");
//        Account data = gson.fromJson("xxx", Account.class);
    }



    private void moveToMainFragment() {
        MainFragment fragment = new MainFragment();
        //R.id.container_id  ->   Parent activity container.
        requireActivity().getSupportFragmentManager().beginTransaction().
                replace(R.id.container_id,fragment).commit();
    }
}
