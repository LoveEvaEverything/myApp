package com.sonny.myapp;

public class Account {
    String name;
    String password;
}
