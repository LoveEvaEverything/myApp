package com.sonny.myapp;

public class Bag {

    float price;
    String brand;

    int size;
    String color;
}
