package com.sonny.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.FragmentManager;
import android.os.Bundle;
import android.util.Log;

import com.google.gson.Gson;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Account myAccount = new Account();
//        myAccount.password = "123HT";
//        myAccount.name = "Sonny";
//
//        Account myAccount01 = new Account();
//        myAccount01.password = "321";
//        myAccount01.name = "Jack";
//
//        Account[] accounts = new Account[2];
//        accounts[0] = myAccount;
//        accounts[1] = myAccount01;
//
//        Gson gson = new Gson();
//
//        String data = gson.toJson(accounts);
//        Log.d("GXL",data);

    }
//
//    @Override
//    public void onBackPressed(){
//        FragmentManager fm = getFragmentManager();
//        if (fm.getBackStackEntryCount() > 0) {
//            fm.popBackStack();
//        } else {
//            super.onBackPressed();
//        }
//    }
}