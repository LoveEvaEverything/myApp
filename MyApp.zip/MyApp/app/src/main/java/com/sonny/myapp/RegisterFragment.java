package com.sonny.myapp;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class RegisterFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.register_fragment, container,false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        save(view);
    }

    private void save(@NonNull View view) {
        EditText accountET = view.findViewById(R.id.account_et_id);

        EditText passFirstET = view.findViewById(R.id.pass_first_et_id);
        EditText passSecondET = view.findViewById(R.id.pass_second_et_id);

        Button saveButton = view.findViewById(R.id.save_id);
        saveButton.setOnClickListener(v->{
            String accountInput  = accountET.getText().toString();
            String pass01Input = passFirstET.getText().toString();
            String pass02Input = passSecondET.getText().toString();


            Log.d("Sonny", "The data is " + accountInput);// Suggested. ⬆️
//            Toast.makeText(requireContext(),"The data is " +  accountInput, Toast.LENGTH_LONG).show();

        });
    }


}
